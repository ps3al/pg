<?php
get_header(); ?>

<h1><?php the_title(); ?></h1>
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <section>
            <?php the_content(); ?>
        </section>
    <?php endwhile; ?>
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.', 'khuni1x' ); ?></p>
<?php endif; ?>

<?php get_footer(); ?>