<?php
if ( ! defined( 'ABSPATH' ) ) exit; // NO DIRECT ACCESS

if ( !class_exists( 'SMAgile' ) ):

class SMAgileTheme extends SMThemeLoader {

	public function __construct() {

		load_theme_textdomain( 'khuni1x', get_template_directory() . '/languages' );


		add_action('wp_enqueue_scripts', array(&$this,'load_scripts'));
		add_action('wp_enqueue_scripts', array(&$this,'load_styles'),10);
		add_action( 'after_setup_theme', array(&$this, 'load_functions' ),10);
		add_action( 'after_setup_theme', array(&$this, 'theme_supports' ),10);
		add_action( 'after_setup_theme', array(&$this, 'create_menus' ),10);

		require SM_THEMEDIR . '/inc/classes/sidebars.php';

		$is_login = in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ));
		if(!is_admin() && !$is_login){
			require SM_THEMEDIR . '/inc/classes/navwalker.php';
		} else {
			require SM_THEMEDIR . '/inc/classes/admin.php';
			require SM_THEMEDIR . '/inc/classes/options.php';
		}

		add_filter( 'excerpt_length', array(&$this, 'stack_excerpt_length'), 999 );


	}

	function stack_excerpt_length( $length ) {
		return 25;
	}


	function load_scripts(){


		if (!is_admin()) {

			wp_deregister_script( 'jquery' );
			wp_enqueue_script( 'jquery', get_template_directory_uri() . '/assets/js/jquery.min.js', false, null, true);

			wp_deregister_script( 'bootstrap' );
			wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/bootstrap/js/bootstrap.min.js', false, null, true);

			wp_deregister_script( 'owlcarousel' );
			wp_enqueue_script( 'owlcarousel', get_template_directory_uri() . '/assets/owlcarousel/js/owl.carousel.min.js', false, null, true);

			wp_deregister_script( 'jquerymixitup' );
			wp_enqueue_script( 'jquerymixitup', get_template_directory_uri() . '/assets/js/jquery.mixitup.js', false, null, true);

			wp_deregister_script( 'jquerystellar' );
			wp_enqueue_script( 'jquerystellar', get_template_directory_uri() . '/assets/js/jquery.stellar.min.js', false, null, true);

			wp_deregister_script( 'jquerymagnificpopup' );
			wp_enqueue_script( 'jquerymagnificpopup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', false, null, true);

			wp_deregister_script( 'wow' );
			wp_enqueue_script( 'wow', get_template_directory_uri() . '/assets/js/wow.min.js', false, null, true);

			wp_deregister_script( 'formcontact' );
			wp_enqueue_script( 'formcontact', get_template_directory_uri() . '/assets/js/form-contact.js', false, null, true);

			wp_deregister_script( 'scripts' );
			wp_enqueue_script( 'scripts', get_template_directory_uri() . '/assets/js/scripts.js', false, null, true);

		}

	}


	function load_styles(){

		if (!is_admin()) {

			wp_deregister_style( 'bootstrap' );
			wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/bootstrap/css/bootstrap.min.css', false, null, 'all' );

			wp_deregister_style( 'style-1' );
			wp_enqueue_style( 'style-1', 'https://fonts.googleapis.com/css?family=Lato:300,400,700,900', false, null, 'all' );

			wp_deregister_style( 'fontawesome' );
			wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/assets/fonts/font-awesome.min.css', false, null, 'all' );

			wp_deregister_style( 'owlcarousel' );
			wp_enqueue_style( 'owlcarousel', get_template_directory_uri() . '/assets/owlcarousel/css/owl.carousel.css', false, null, 'all' );

			wp_deregister_style( 'owltheme' );
			wp_enqueue_style( 'owltheme', get_template_directory_uri() . '/assets/owlcarousel/css/owl.theme.css', false, null, 'all' );

			wp_deregister_style( 'magnificpopup' );
			wp_enqueue_style( 'magnificpopup', get_template_directory_uri() . '/assets/css/magnific-popup.css', false, null, 'all' );

			wp_deregister_style( 'animate' );
			wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/css/animate.min.css', false, null, 'all' );

			wp_deregister_style( 'style' );
			wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css', false, null, 'all' );

			wp_deregister_style( 'responsive' );
			wp_enqueue_style( 'responsive', get_template_directory_uri() . '/assets/css/responsive.css', false, null, 'all' );

		}
		
	}


	function load_functions() {
		require SM_THEMEDIR . '/inc/functions/theme_functions.php';
	}


	function theme_supports(){

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 825, 510, true );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
		) );

		/*
		 * Enable support for Post Formats.
		 */
		add_theme_support( 'post-formats', array(
			'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
		) );

	}


	function create_menus() {

		// Add menus.
		register_nav_menus( array(
			'main' => __( 'Main Menu', 'khuni1x' ),
		) );

	}

}

	new SMAgileTheme();

endif;
