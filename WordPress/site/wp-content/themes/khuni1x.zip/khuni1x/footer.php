
        <!-- / END HOMEPAGE DESIGN AREA -->
        <!-- START ABOUT DESIGN AREA -->
        <!-- / END ABOUT DESIGN AREA -->
        <!-- START SERVICES DESIGN AREA -->
        <!-- / END SERVICES DESIGN AREA -->
        <!-- START WORK DESIGN AREA -->
        <!-- / END START WORK DESIGN AREA -->
        <!-- START TESTIMONIAL DESIGN AREA -->
        <!-- / END TESTIMONIAL DESIGN AREA -->
        <!-- START CONTACT DESIGN AREA -->
        <!-- / END CONTACT DESIGN AREA -->
        <!-- START FOOTER DESIGN AREA -->
        <footer class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center wow fadeInUp" data-wow-delay="1s">
                        <p><?php _e( '&copy; 2016 Khuni | All RightReserved.', 'khuni1x' ); ?></p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- / END FOOTER DESIGN AREA -->
        <!-- LATEST JQUERY -->
        <!-- BOOTSTRAP JS -->
        <!-- OWL CAROUSEL JS  -->
        <!-- MIXITUP JS -->
        <!-- PARALLAX JS -->
        <!-- MAGNIFICANT JS -->
        <!-- WOW JS -->
        <!-- CONTACT FORM JS -->
        <!-- scripts js -->
        <?php wp_footer(); ?>
    </body>
</html>