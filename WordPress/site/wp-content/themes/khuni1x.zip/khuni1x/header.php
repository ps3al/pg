<!doctype html>
<html <?php language_attributes(); ?>>
    <head>
        <!-- META -->
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Khuni is a Personal Portfolio Template">
        <meta name="keywords" content="Creativepersonal, resume, cv, portfolio, personal, developer, designer,personal resume, onepage, clean, modern">
        <meta name="author" content="Tanvir Rahman Hridoy">
        <!-- PAGE TITLE -->
        <!-- BOOTSTRAP CSS -->
        <!-- ALL GOOGLE FONTS -->
        <!-- FONT AWESOME CSS -->
        <!-- OWL CAROSEL CSS -->
        <!-- MAGNIFIC CSS -->
        <!-- ANIMATE CSS -->
        <!-- MAIN STYLE CSS -->
        <!-- RESPONSIVE CSS -->
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
        <?php wp_head(); ?>
    </head>
    <body>
        <!-- START PRELOADER -->
        <div class="preloader">
            <div class="status">
                <div class="status-mes"></div>
            </div>
        </div>
        <!-- / END PRELOADER -->
        <!-- START HOMEPAGE DESIGN AREA -->
        <header id="home" class="welcome-area">
            <div class="header-top-area">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                            <!-- START LOGO DESIGN AREA -->
                            <div class="logo">
                                <a href="index.html"><?php _e( 'Khuni', 'khuni1x' ); ?></a>
                            </div>
                            <!-- END LOGO DESIGN AREA -->
                        </div>
                        <div class="col-sm-9">
                            <!-- START MENU DESIGN AREA -->
                            <div class="mainmenu">
                                <div class="navbar navbar-nobg">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                            <span class="sr-only"><?php _e( 'Toggle navigation', 'khuni1x' ); ?></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>
                                    </div>
                                    <div class="navbar-collapse collapse">
                                        <?php wp_nav_menu( array(
                                                'menu' => 'Main Menu',
                                                'menu_class' => 'nav navbar-nav navbar-right',
                                                'menu_id' => 'main',
                                                'container' => '',
                                                'theme_location' => 'main',
                                                'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                                                'walker' => new wp_bootstrap_navwalker()
                                        ) ); ?>
                                    </div>
                                </div>
                            </div>
                            <!-- END MENU DESIGN AREA -->
                        </div>
                    </div>
                </div>
            </div>
        </header>
