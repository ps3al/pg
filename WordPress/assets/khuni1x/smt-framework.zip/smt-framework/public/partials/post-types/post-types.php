<?php
/**
 * Created by PhpStorm.
 * User: MacBook
 * Date: 4.03.2017
 * Time: 17:24
 */
register_post_type('service', array(
	'labels' =>
		array(
			'name' => __( 'Service', 'khuni1x' ),
			'singular_name' => __( 'Service', 'khuni1x' )
		),
	'public' => true,
	'supports' => array( 'title', 'excerpt' ),
	'show_in_menu' => true
));

register_post_type('portfolio', array(
	'labels' =>
		array(
			'name' => __( 'Portfolio', 'khuni1x' ),
			'singular_name' => __( 'Portfolio', 'khuni1x' )
		),
	'public' => true,
	'supports' => array( 'title', 'thumbnail' ),
	'has_archive' => true,
	'taxonomies' => array( 'portfolio-type' )
));

register_post_type('testimonial', array(
	'labels' =>
		array(
			'name' => __( 'Testimonial', 'khuni1x' ),
			'singular_name' => __( 'Testimonial', 'khuni1x' )
		),
	'public' => true,
	'supports' => array( 'title', 'excerpt' ),
	'show_in_menu' => true
));

register_taxonomy('portfolio-type', 'portfolio', array(
	'labels' =>
		array(
			'name' => __( 'Portfolio Categories', 'khuni1x' ),
			'singular_name' => __( 'Category', 'khuni1x' )
		),
	'hierarchical' => true
));