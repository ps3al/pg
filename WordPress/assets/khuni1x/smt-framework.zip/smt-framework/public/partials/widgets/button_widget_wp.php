<?php
/**
 * SM-Theme Button Widget
 *
 * @author SM-Themes
 * @version 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! ( class_exists( 'Button_Widget_WP' ) ) ) {
	class Button_Widget_WP extends WP_Widget {

		function Button_Widget_WP() {
			parent::__construct(
				'button-widget-wp', // Base ID
				'Button wp', // Name
				array( 'description' => 'Button', ) // Args
			);
			$this->load_fields();
		}

		function widget( $args, $instance ) {

			extract( $args );
			$title       = apply_filters( 'widget_title', get_field( 'title', 'widget_'.$widget_id ) );

			$atts = array(
				'type' => get_field( 'type', 'widget_'.$widget_id ),
				'link' => get_field( 'link', 'widget_'.$widget_id ),
				'text' => get_field( 'text', 'widget_'.$widget_id ),
				'target' => get_field( 'target', 'widget_'.$widget_id ),
			);

			echo button($atts);
		}


		public function form( $instance ) {
//			return 'noform';
		}

		public function load_fields(){


			if( function_exists('acf_add_local_field_group') ):

				acf_add_local_field_group(array (
					'key' => 'group_57d7df0896eab',
					'title' => 'Button',
					'fields' => array (
						array (
							'key' => 'field_57d7df93f21bb',
							'label' => 'Title',
							'name' => 'title',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
						array (
							'key' => 'field_57d7df48d6fd9',
							'label' => 'Type',
							'name' => 'type',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
						array (
							'key' => 'field_57d7df51d6fda',
							'label' => 'Link',
							'name' => 'link',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
						array (
							'key' => 'field_57d7df5fd6fdc',
							'label' => 'Target',
							'name' => 'target',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
						array (
							'key' => 'field_57d7df6bd6fdd',
							'label' => 'Text',
							'name' => 'text',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
					),
					'location' => array (
						array (
							array (
								'param' => 'widget',
								'operator' => '==',
								'value' => 'button-widget-wp',
							),
						),
					),
					'menu_order' => 0,
					'position' => 'normal',
					'style' => 'default',
					'label_placement' => 'top',
					'instruction_placement' => 'label',
					'hide_on_screen' => '',
					'active' => 1,
					'description' => '',
				));

			endif;


		}

	}

}
register_widget( 'Button_Widget_WP' );


?>