<?php

/*
Widget Name: Button
Description: Renders a button with multiple styles.
Author: SM Themes
Author URI: http://portfoliotheme.org
*/

class Button_Widget_SO extends SiteOrigin_Widget {


    function __construct() {
        //Here you can do any preparation required before calling the parent constructor, such as including additional files or initializing variables.

        //Call the parent constructor with the required arguments.
        parent::__construct(
            "button_widget_so",
            __("Button", "khuni1x"),
            array(
                "description" => __("SMT Renders a button with multiple styles..", "khuni1x"),
                "panels_icon" => "dashicons dashicons-minus",
            ),
            array(),
            array(
                "widget_title" => array(
                    "type" => "text",
                    "label" => __("Title", "khuni1x"),
                ),
                "type" => array(
	                "type" => "text",
	                "description" => __("Type. ", "khuni1x"),
	                "label" => __("Type", "khuni1x"),
	                "default" => __("black", "khuni1x"),
                ),
                "link" => array(
	                "type" => "text",
	                "description" => __("Link. ", "khuni1x"),
	                "label" => __("Link", "khuni1x"),
	                "default" => __("#", "khuni1x"),
                ),
                "target" => array(
	                "type" => "text",
	                "description" => __("Target. ", "khuni1x"),
	                "label" => __("Target", "khuni1x"),
	                "default" => __("_self", "khuni1x"),
                ),
                "text" => array(
                    "type" => "text",
                    "description" => __("The button title or text. ", "khuni1x"),
                    "label" => __("Button Text", "khuni1x"),
                    "default" => __("Read More", "khuni1x"),
                ),
            )
        );

        add_action( 'admin_head', array(&$this,'admin_inline_js' ));

    }

    function admin_inline_js(){
        ?>
        <script type="text/javascript">
            (function($) {
                $(document).ready(function () {
//						alert(1);
                    $("[id*='<?php echo '-button-widget-';?>']").remove();
                });
            })(jQuery);
        </script>
        <?php
    }

    function get_style_name($instance) {
        return '';
    }

    function get_template_name($instance) {
        return 'view';
    }

    function get_template_dir($instance) {
        return 'template';
    }


    function get_template_variables($instance, $args) {
//        var_dump($args);
//        die;
        return array(
            "type" => $instance["type"],
            "link" => (!empty($instance['link'])) ? sow_esc_url($instance['link']) : '',
            "target" => $instance["target"],
            "text" => $instance["text"],
        );
    }


}

siteorigin_widget_register('button_widget_so', __FILE__, 'Button_Widget_SO');

function button_img_src( $banner_url, $widget_meta ) {
    if( $widget_meta['ID'] == 'button-widget-so') {
        $banner_url = plugin_dir_url(__FILE__) . 'inc/widgets/button/assets/banner.svg';
    }
    return $banner_url;
}
//add_filter( 'siteorigin_widgets_widget_banner', 'button_img_src', 10, 2);
