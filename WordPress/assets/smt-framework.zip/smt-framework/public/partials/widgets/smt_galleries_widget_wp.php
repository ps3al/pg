<?php
/**
 * SM-Theme Galleries Widget
 *
 * @author SM-Themes
 * @version 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! ( class_exists( 'SMT_Galleries_Widget_WP' ) ) ) {
	class SMT_Galleries_Widget_WP extends WP_Widget {

		function SMT_Galleries_Widget_WP() {
			parent::__construct(
				'smt-galleries-widget-wp', // Base ID
				'SMT Galleries wp', // Name
				array( 'description' => 'Galleries List', ) // Args
			);
			$this->load_fields();
		}

		function widget( $args, $instance ) {

			extract( $args );
			$title       = apply_filters( 'widget_title', get_field( 'title', 'widget_'.$widget_id ) );
			$items = get_field( 'galleries_links', 'widget_'.$widget_id );

			$output='';

			if ( $title ) {
				$output .= '<h4 class="widget-title">' . $title . '</h4>';
			}

			$output .= '<ul class="galleries">';

			foreach ( $items as $galleries ) {

				$output .= '<li> <a href="' . $galleries['galleries_link'] . '"><i class="' . $galleries['galleries_icon'] . ' ' . $galleries['galleries_class'] . '"></i></a> </li>';

			}
			$output .='</ul>';
			?>
			<?php
			echo $output;
		}


		public function form( $instance ) {
			return 'noform';
		}

		public function load_fields(){


			if( function_exists('acf_add_local_field_group') ):

				acf_add_local_field_group(array (
					'key' => 'group_56a7dfd01fd1c1',
					'title' => 'Galleries List',
					'fields' => array (
						array (
							'key' => 'field_56a7e6956a5111',
							'label' => 'Title',
							'name' => 'title',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
						array (
							'key' => 'field_56a7dfd6db9231',
							'label' => 'Galleries Links',
							'name' => 'galleries_links',
							'type' => 'repeater',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'collapsed' => 'field_56a7dfeedb9241',
							'min' => '',
							'max' => '',
							'layout' => 'block',
							'button_label' => 'Add Galleries Link',
							'sub_fields' => array (
								array (
									'key' => 'field_56a7dfeedb9241',
									'label' => 'Galleries Icon',
									'name' => 'galleries_icon',
									'type' => 'text',
									'instructions' => '',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => array (
										'width' => '',
										'class' => '',
										'id' => '',
									),
									'default_icon' => 2,
								),
								array (
									'key' => 'field_56a7e010db9251',
									'label' => 'Galleries Link',
									'name' => 'galleries_link',
									'type' => 'text',
									'instructions' => '',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => array (
										'width' => '',
										'class' => '',
										'id' => '',
									),
									'default_value' => '',
									'placeholder' => '',
									'prepend' => '',
									'append' => '',
									'maxlength' => '',
									'readonly' => 0,
									'disabled' => 0,
								),
								array (
									'key' => 'field_56a7e01bdb9261',
									'label' => 'Class',
									'name' => 'class',
									'type' => 'text',
									'instructions' => '',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => array (
										'width' => '',
										'class' => '',
										'id' => '',
									),
									'default_value' => '',
									'placeholder' => '',
									'prepend' => '',
									'append' => '',
									'maxlength' => '',
									'readonly' => 0,
									'disabled' => 0,
								),
							),
						),
					),
					'location' => array (
						array (
							array (
								'param' => 'widget',
								'operator' => '==',
								'value' => 'smt-galleries-widget-wp',
							),
						),
					),
					'menu_order' => 0,
					'position' => 'normal',
					'style' => 'default',
					'label_placement' => 'top',
					'instruction_placement' => 'label',
					'hide_on_screen' => '',
					'active' => 1,
					'description' => '',
				));

			endif;

		}

	}

}
register_widget( 'SMT_Galleries_Widget_WP' );


?>