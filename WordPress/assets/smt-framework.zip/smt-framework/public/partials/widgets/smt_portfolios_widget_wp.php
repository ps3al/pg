<?php
/**
 * SM-Theme Portfolios Widget
 *
 * @author SM-Themes
 * @version 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! ( class_exists( 'SMT_Portfolios_Widget_WP' ) ) ) {
	class SMT_Portfolios_Widget_WP extends WP_Widget {

		function SMT_Portfolios_Widget_WP() {
			parent::__construct(
				'smt-portfolios-widget-wp', // Base ID
				'SMT Portfolios wp', // Name
				array( 'description' => 'Portfolios List', ) // Args
			);
			$this->load_fields();
		}

		function widget( $args, $instance ) {

			extract( $args );
			$title       = apply_filters( 'widget_title', get_field( 'title', 'widget_'.$widget_id ) );
			$items = get_field( 'portfolios_links', 'widget_'.$widget_id );

			$output='';

			if ( $title ) {
				$output .= '<h4 class="widget-title">' . $title . '</h4>';
			}

			$output .= '<ul class="portfolios">';

			foreach ( $items as $portfolios ) {

				$output .= '<li> <a href="' . $portfolios['portfolios_link'] . '"><i class="' . $portfolios['portfolios_icon'] . ' ' . $portfolios['portfolios_class'] . '"></i></a> </li>';

			}
			$output .='</ul>';
			?>
			<?php
			echo $output;
		}


		public function form( $instance ) {
		return 'noform';
		}

		public function load_fields(){


			if( function_exists('acf_add_local_field_group') ):

				acf_add_local_field_group(array (
					'key' => 'group_56a7dfd01fd1c',
					'title' => 'Portfolios List',
					'fields' => array (
						array (
							'key' => 'field_56a7e6956a511',
							'label' => 'Title',
							'name' => 'title',
							'type' => 'text',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'default_value' => '',
							'placeholder' => '',
							'prepend' => '',
							'append' => '',
							'maxlength' => '',
							'readonly' => 0,
							'disabled' => 0,
						),
						array (
							'key' => 'field_56a7dfd6db923',
							'label' => 'Portfolios Links',
							'name' => 'portfolios_links',
							'type' => 'repeater',
							'instructions' => '',
							'required' => 0,
							'conditional_logic' => 0,
							'wrapper' => array (
								'width' => '',
								'class' => '',
								'id' => '',
							),
							'collapsed' => 'field_56a7dfeedb924',
							'min' => '',
							'max' => '',
							'layout' => 'block',
							'button_label' => 'Add Portfolios Link',
							'sub_fields' => array (
								array (
									'key' => 'field_56a7dfeedb924',
									'label' => 'Portfolios Icon',
									'name' => 'portfolios_icon',
									'type' => 'text',
									'instructions' => '',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => array (
										'width' => '',
										'class' => '',
										'id' => '',
									),
									'default_icon' => 2,
								),
								array (
									'key' => 'field_56a7e010db925',
									'label' => 'Portfolios Link',
									'name' => 'portfolios_link',
									'type' => 'text',
									'instructions' => '',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => array (
										'width' => '',
										'class' => '',
										'id' => '',
									),
									'default_value' => '',
									'placeholder' => '',
									'prepend' => '',
									'append' => '',
									'maxlength' => '',
									'readonly' => 0,
									'disabled' => 0,
								),
								array (
									'key' => 'field_56a7e01bdb926',
									'label' => 'Class',
									'name' => 'class',
									'type' => 'text',
									'instructions' => '',
									'required' => 0,
									'conditional_logic' => 0,
									'wrapper' => array (
										'width' => '',
										'class' => '',
										'id' => '',
									),
									'default_value' => '',
									'placeholder' => '',
									'prepend' => '',
									'append' => '',
									'maxlength' => '',
									'readonly' => 0,
									'disabled' => 0,
								),
							),
						),
					),
					'location' => array (
						array (
							array (
								'param' => 'widget',
								'operator' => '==',
								'value' => 'smt-portfolios-widget-wp',
							),
						),
					),
					'menu_order' => 0,
					'position' => 'normal',
					'style' => 'default',
					'label_placement' => 'top',
					'instruction_placement' => 'label',
					'hide_on_screen' => '',
					'active' => 1,
					'description' => '',
				));

			endif;

		}

	}

}
register_widget( 'SMT_Portfolios_Widget_WP' );


?>