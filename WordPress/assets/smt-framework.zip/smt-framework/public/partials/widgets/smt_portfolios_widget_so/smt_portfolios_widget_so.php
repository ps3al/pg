<?php
/*
Widget Name: Hello World Widget
Description: An example widget which displays 'Hello world!'.
Author: Me
Author URI: http://example.com
Widget URI: http://example.com/hello-world-widget-docs,
Video URI: http://example.com/hello-world-widget-video
*/

class SMT_Portfolios_Widget_SO extends SiteOrigin_Widget {


	function __construct() {
		//Here you can do any preparation required before calling the parent constructor, such as including additional files or initializing variables.

		//Call the parent constructor with the required arguments.
		parent::__construct(
		// The unique id for your widget.
			'smt_portfolios_widget_so',

			// The name of the widget for display purposes.
			__('SMT Portfolios so', 'portfolios-widget-text-domain'),

			// The $widget_options array, which is passed through to WP_Widget.
			// It has a couple of extras like the optional help URL, which should link to your sites help or support page.
			array(
				'description' => __('Portfolios List', 'portfolios-widget-text-domain'),
				'help'        => 'http://example.com/hello-world-widget-docs',
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),

			//The $form_options array, which describes the form fields used to configure SiteOrigin widgets. We'll explain these in more detail later.
			array(
				'id' => array(
					'type' => 'text',
					'label' => __('ID goes here.', 'siteorigin-widgets'),
					'default' => ''
				),
				'class' => array(
					'type' => 'text',
					'label' => __('Class goes here.', 'siteorigin-widgets'),
					'default' => ''
				),
				'content' => array(
					'type' => 'textarea',
					'label' => __('Content goes here.', 'siteorigin-widgets'),
					'default' => ''
				),
			),

			//The $base_folder path string.
			plugin_dir_path(__FILE__)
		);

		add_action( 'admin_head', array(&$this,'admin_inline_js' ));

	}

		function admin_inline_js(){
		?>
			<script type="text/javascript">
				(function($) {
					$(document).ready(function () {
//						alert(1);
						$("[id*='<?php echo '-portfolios-widget-';?>']").remove();
					});
				})(jQuery);
			</script>
		<?php
		}


	function get_style_name($instance) {
		return '';
	}

	function get_template_name($instance) {
		return 'view';
	}

	function get_template_dir($instance) {
		return 'template';
	}

}

siteorigin_widget_register('SMT_Portfolios_Widget_SO', __FILE__, 'SMT_Portfolios_Widget_SO');

function portfolios_img_src( $banner_url, $widget_meta ) {
	if( $widget_meta['ID'] == 'smt-portfolios-widget-so') {
		$banner_url = plugin_dir_url(__FILE__) . 'inc/widgets/portfolios/assets/banner.svg';
	}
	return $banner_url;
}
add_filter( 'siteorigin_widgets_widget_banner', 'portfolios_img_src', 10, 2);


?>