<?php
	echo do_shortcode('[sm_bartag id="' . $instance['id'] . '" class="' . $instance['class'] . '"]' . $instance['content'] . '[/sm_bartag]');
?>