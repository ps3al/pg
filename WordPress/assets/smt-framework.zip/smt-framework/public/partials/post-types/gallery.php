<?php
/**
 * Created by PhpStorm.
 * User: MacBook
 * Date: 27.02.16
 * Time: 00:57
 */


// Register Custom Post Type
function gallery_post_type() {

	$labels = array(
		'name'                  => _x( 'Galleries', 'Post Type General Name', 'sipsak' ),
		'singular_name'         => _x( 'Gallery', 'Post Type Singular Name', 'sipsak' ),
		'menu_name'             => __( 'Galleries', 'sipsak' ),
		'name_admin_bar'        => __( 'Gallery', 'sipsak' ),
		'archives'              => __( 'Gallery Archives', 'sipsak' ),
		'parent_item_colon'     => __( 'Parent Item:', 'sipsak' ),
		'all_items'             => __( 'All Galleries', 'sipsak' ),
		'add_new_item'          => __( 'Add New Gallery', 'sipsak' ),
		'add_new'               => __( 'Add New', 'sipsak' ),
		'new_item'              => __( 'New Gallery', 'sipsak' ),
		'edit_item'             => __( 'Edit Gallery', 'sipsak' ),
		'update_item'           => __( 'Update Gallery', 'sipsak' ),
		'view_item'             => __( 'View Gallery', 'sipsak' ),
		'search_items'          => __( 'Search Gallery', 'sipsak' ),
		'not_found'             => __( 'Not found', 'sipsak' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'sipsak' ),
		'featured_image'        => __( 'Featured Image', 'sipsak' ),
		'set_featured_image'    => __( 'Set featured image', 'sipsak' ),
		'remove_featured_image' => __( 'Remove featured image', 'sipsak' ),
		'use_featured_image'    => __( 'Use as featured image', 'sipsak' ),
		'insert_into_item'      => __( 'Insert into gallery', 'sipsak' ),
		'uploaded_to_this_item' => __( 'Uploaded to this gallery', 'sipsak' ),
		'items_list'            => __( 'Galleries list', 'sipsak' ),
		'items_list_navigation' => __( 'Galleries list navigation', 'sipsak' ),
		'filter_items_list'     => __( 'Filter galleries list', 'sipsak' ),
	);
	$args   = array(
		'label'               => __( 'Gallery', 'sipsak' ),
		'description'         => __( 'Gallery Post Type', 'sipsak' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'thumbnail' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-camera',
		'show_in_admin_bar'   => true,
		'show_in_nav_menus'   => true,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'gallery', $args );
}

add_action( 'init', 'gallery_post_type', 0 );

function gallery_item_taxonomy_category() {

	$labels = array(
		'name'                       => _x( 'Categories', 'Taxonomy General Name', 'sipsak' ),
		'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'sipsak' ),
		'menu_name'                  => __( 'Item Categories', 'sipsak' ),
		'all_items'                  => __( 'All Item Categories', 'sipsak' ),
		'parent_item'                => __( 'Parent Item Category', 'sipsak' ),
		'parent_item_colon'          => __( 'Parent Item Category:', 'sipsak' ),
		'new_item_name'              => __( 'New Item Category Name', 'sipsak' ),
		'add_new_item'               => __( 'Add New Item Category', 'sipsak' ),
		'edit_item'                  => __( 'Edit Item Category', 'sipsak' ),
		'update_item'                => __( 'Update Item Category', 'sipsak' ),
		'view_item'                  => __( 'View Item Category', 'sipsak' ),
		'separate_items_with_commas' => __( 'Separate categories with commas', 'sipsak' ),
		'add_or_remove_items'        => __( 'Add or remove categories', 'sipsak' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'sipsak' ),
		'popular_items'              => __( 'Popular Categories', 'sipsak' ),
		'search_items'               => __( 'Search Categories', 'sipsak' ),
		'not_found'                  => __( 'Not Found', 'sipsak' ),
		'no_terms'                   => __( 'No Categories', 'sipsak' ),
		'items_list'                 => __( 'Categories list', 'sipsak' ),
		'items_list_navigation'      => __( 'Categories list navigation', 'sipsak' ),
	);
	$args   = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => false,
		'show_in_nav_menus' => false,
		'show_tagcloud'     => true,
	);
	register_taxonomy( 'gallery_item_category', array( 'gallery' ), $args );

}

add_action( 'init', 'gallery_item_taxonomy_category', 0 );

function gallery_item_taxonomy_tag() {

	$labels = array(
		'name'                       => _x( 'Tags', 'Taxonomy General Name', 'sipsak' ),
		'singular_name'              => _x( 'Tag', 'Taxonomy Singular Name', 'sipsak' ),
		'menu_name'                  => __( 'Item Tags', 'sipsak' ),
		'all_items'                  => __( 'All Item Tags', 'sipsak' ),
		'new_item_name'              => __( 'New Item Tag Name', 'sipsak' ),
		'add_new_item'               => __( 'Add New Item Tag', 'sipsak' ),
		'edit_item'                  => __( 'Edit Item Tag', 'sipsak' ),
		'update_item'                => __( 'Update Item Tag', 'sipsak' ),
		'view_item'                  => __( 'View Item Tag', 'sipsak' ),
		'separate_items_with_commas' => __( 'Separate tags with commas', 'sipsak' ),
		'add_or_remove_items'        => __( 'Add or remove tags', 'sipsak' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'sipsak' ),
		'popular_items'              => __( 'Popular Tags', 'sipsak' ),
		'search_items'               => __( 'Search Tags', 'sipsak' ),
		'not_found'                  => __( 'Not Found', 'sipsak' ),
		'no_terms'                   => __( 'No Tags', 'sipsak' ),
		'items_list'                 => __( 'Tags list', 'sipsak' ),
		'items_list_navigation'      => __( 'Tags list navigation', 'sipsak' ),
	);
	$args   = array(
		'labels'            => $labels,
		'hierarchical'      => false,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => false,
		'show_in_nav_menus' => false,
		'show_tagcloud'     => true,
	);
	register_taxonomy( 'gallery_item_tag', array( 'gallery' ), $args );

}

add_action( 'init', 'gallery_item_taxonomy_tag', 0 );

function my_remove_meta_boxes() {
	remove_meta_box( 'gallery_item_categorydiv', 'gallery', 'side' );
	remove_meta_box( 'tagsdiv-gallery_item_tag', 'gallery', 'side' );
}

add_action( 'admin_menu', 'my_remove_meta_boxes' );


function wpb_change_gallery_title_text( $title ){
	$screen = get_current_screen();

	if  ( 'gallery' == $screen->post_type ) {
		$title = 'Enter gallery name';
	}

	return $title;
}

add_filter( 'enter_title_here', 'wpb_change_gallery_title_text' );


// Galleries Grid Shortcode
function galleries_grid_shortcode( $atts ) {
	ob_start();
	// Attributes
	extract( shortcode_atts(
			array(
				'galleries'    => 'all',
				'show_title'   => true,
				'show_desc'    => true,
				'show_meta'    => true,
				'list_orderby' => 'order',
				'list_order'   => 'ASC'
			), $atts )
	);
	?>
	<div class="portfolio-grid">
		<ul class="isotope items">
			<?php

			//general query
			$args = array(
				'post_status' => 'publish',
				'post_type'   => 'gallery',
				'orderby'     => $list_orderby,
				'order'       => $list_order,
				'showposts'   => 1000
			);

			if ( 'all' != $galleries ) {
				//gallery id numbers
				$ids = ! empty( $galleries ) ? explode( ",", trim( $galleries ) ) : array();

				if ( ! empty ( $ids ) ) {
					$args = array_merge( $args, array( 'post__in' => $ids ) );
				}
			}

			$theQuery = query_posts( $args );

			while ( have_posts() ) : the_post();

				$title       = get_field( 'title' );
				$description = get_field( 'description' );
				$items       = get_field( 'gallery_items' );

//				$items_count = ( $items_count == false ) ? 0 : $items_count;

//				get_field( 'gallery_items' );
//				var_dump(get_field( 'gallery_items' ));


				$date = get_field( 'date' );

				?>
				<li class="item">
					<figure class="overlay"><a href="<?php echo get_permalink(); ?>">
							<div class="text-overlay caption">
								<?php if ( $show_title || $show_desc || $show_meta ): ?>
									<div class="info">
										<?php if ( $show_title ): ?>
											<h2 class="post-title"><?php echo $title; ?></h2>
										<?php endif; ?>
										<?php if ( $show_desc ): ?>
											<h6 class="post-title"><?php echo $description; ?></h6>
										<?php endif; ?>
										<?php if ( $show_meta ): ?>
											<div class="meta">
												<span
													class="count"><?php echo $items == false ? '0' : count( $items ); ?>
													Photos</span>
												<span class="date"><?php echo $date; ?></span>
											</div>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							</div>
							<img src="<?php echo get_featured_image_url( $post->ID, 'tn440x300' ); ?>"
							     alt=""/> </a>
					</figure>
				</li>
				<?php
			endwhile;

			wp_reset_query();

			?>
		</ul>
		<!-- /.isotope -->
	</div>
	<!-- /.portfolio-grid -->
	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

add_shortcode( 'galleries-grid', 'galleries_grid_shortcode' );



function galleries_grid_vc() {
	vc_map( array(
		"name"     => "Galleries Grid",
		"base"     => "galleries-grid",
		"class"    => "",
		"category" => "Content",
		"params"   => array(
			array(
				'param_name' => 'galleries',
				'heading'    => "Select Galleries",
				'type'       => 'dropdown_multi',
				"value"      => array_merge( array( "All Galleries" => "" ), array_flip( get_galleries_list() ) )
			),
			array(
				'param_name'  => 'list_orderby',
				'heading'     => 'List Order By',
				'type'        => 'dropdown',
				"value"       => array(
					'Date'       => 'date',
					'Order'      => 'order',
					'Author'     => 'author',
					'Title'      => 'title',
					'Modified'   => 'modified',
					'ID'         => 'ID',
					'Randomized' => 'rand',
				),
				'std'         => 'order',
				'save_always' => true
			),
			array(
				'param_name'  => 'list_order',
				'heading'     => 'List Order',
				'type'        => 'dropdown',
				"value"       => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC',
				),
				'save_always' => true
			),
			array(
				'param_name'  => 'show_title',
				'heading'     => "Show Title",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => true,
				"std"         => true
			),
			array(
				'param_name'  => 'show_desc',
				'heading'     => "Show Description",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => true,
				"std"         => true
			),
			array(
				'param_name'  => 'show_meta',
				'heading'     => "Show Meta",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => true,
				"std"         => true
			),
			array(
				'param_name'  => 'id',
				'heading'     => 'ID',
				'description' => 'Unique ID',
				'type'        => 'textfield',
				'value'       => ''
			),
			array(
				"type"        => "textfield",
				"holder"      => "div",
				"class"       => "",
				"heading"     => "Class",
				"param_name"  => "class",
				"value"       => "",
				"description" => "Class Name."
			),
		),
	) );
}

add_action( 'vc_before_init', 'galleries_grid_vc' );



function get_galleries_list() {

	$galleries_query = query_posts( 'posts_per_page=-1&post_type=gallery&orderby=title&order=ASC' );
	$galleries_array = array();
	if ( is_array( $galleries_array ) ) {
		foreach ( $galleries_query as $gallery ) {
			$galleries_array[ $gallery->ID ] = $gallery->post_title;
		}
	}
	wp_reset_query();

	return $galleries_array;

}


// Gallery View Shortcode
function gallery_view_shortcode( $atts ) {
	ob_start();
	// Attributes
	extract( shortcode_atts(
			array(
				'gallery'         => '',
				'gallery_type'    => 'fotorama',
				'category_filter' => true,
				'lightbox'        => true,
				'list_orderby'    => 'order',
				'list_order'      => 'ASC'
			), $atts )
	);
	?>
	<?php

	//general query
	$args = array(
		'post_status' => 'publish',
		'post_type'   => 'gallery',
		'post__in'    => array( $gallery ),
		'orderby'     => $list_orderby,
		'order'       => $list_order,
		'showposts'   => 1000
	);


	$theQuery = query_posts( $args );

	while ( have_posts() ) : the_post();

		$title       = get_field( 'title' );
		$description = get_field( 'description' );
		$items       = get_field( 'gallery_items' );

		if ( $items ): ?>
			<?php if ( 'fotorama' == $gallery_type ): ?>
				<div class="fotorama-wrapper">
					<div class="fotorama"
					     data-width="100%"
					     data-height="100%"
					     data-autoplay="8000"
					     data-keyboard="true"
					     data-arrows="true"
					     data-click="false"
					     data-fit="cover"
					     data-swipe="true"
					     data-nav="thumbs"
					     data-transition="slide"
					     data-clicktransition="crossfade"
					     data-thumbwidth="90"
					     data-thumbheight="50">

						<?php foreach ( $items as $image ): ?>
							<img src="<?php echo $image['url']; ?>" data-caption="<?php echo $image['caption']; ?>"
							     data-fit="content"
							     alt=""/>
						<?php endforeach; ?>

					</div>
					<!-- /.fotorama -->
				</div>
			<?php elseif ( 'flow' == $gallery_type ): ?>

				<div class="rev_slider_wrapper" style="background-color:#171717; padding:0px;">
					<div id="flow" class="rev_slider fullscreenbanner" data-version="5.0">
						<ul>
							<?php foreach ( $items as $image ): ?>
								<li data-transition="fade"><img src="<?php echo $image['url']; ?>" alt=""
								                                data-bgposition="center center">
									<?php if ( '' != $image['caption'] ): ?>
										<div class="tp-caption display dark-layer"
										     data-x="40"
										     data-y="bottom"
										     data-voffset="40"
										     data-fontsize="['26','26','26','26']"
										     data-lineheight="['32','32','32','30']"
										     data-transform_idle="o:1;"
										     data-transform_in="y:50px;opacity:0;s:1500;e:Power3.easeOut;"
										     data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
										     data-start="50"
										     data-splitin="none"
										     data-splitout="none"
										     data-responsive_offset="on"
										     style="z-index: 5;"><?php echo $image['caption']; ?></div>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					<!-- /.rev_slider -->
				</div>
				<!-- /.rev_slider_wrapper -->


			<?php elseif ( 'grid' == $gallery_type ):
				?>


				<div class="portfolio-grid">

					<?php if ( $category_filter ): ?>
						<div class="isotope-filter button-group">
							<ul>
								<li><a class="button is-checked" data-filter="*">All</a></li>
								<?php

								$categories = array();
								foreach ( $items as $image ) {
									$xcategories = get_field( 'category', $image['ID'] );
									if ( $xcategories ) {
										foreach ( $xcategories as $category ) {
//							echo ',' . $category->ID;
											$categories[] = $category->name;
										}
									}
								}
								$categories = array_unique( $categories );
								sort( $categories, SORT_LOCALE_STRING );

								foreach ( $categories as $category ):?>
									<li><a class="button"
									       data-filter=".cat-<?php echo $category ?>"><?php echo $category ?></a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
					<ul class="isotope items<?php echo $lightbox ? ' light-gallery' : ''; ?>">
						<?php foreach ( $items as $image ):
							$categories  = '';
							$xcategories = get_field( 'category', $image['ID'] );
							if ( $xcategories ) {
								foreach ( $xcategories as $category ) {
									$categories .= ' cat-' . $category->name;
								}
							}

							?>
							<li class="item<?php echo $categories; ?>">
								<figure class="overlay inverse"><a href="<?php echo $image['url']; ?>" class="lgitem"
								                                   data-sub-html="#caption1">
										<div class="text-overlay caption" id="caption1">
											<div class="info">
												<h2 class="post-title"><?php echo $image['title']; ?></h2>

												<p><?php echo $image['caption']; ?></p>
											</div>
										</div>
										<img src="<?php echo $image['sizes']['tn440x300']; ?>" alt=""/> </a></figure>
							</li>
						<?php endforeach; ?>
					</ul>
					<!-- /.isotope -->
				</div>
				<!-- /.portfolio-grid -->


			<?php elseif ( 'carousel' == $gallery_type ): ?>

				<div class="owl-carousel<?php echo $lightbox ? ' light-gallery' : ''; ?>">
					<?php foreach ( $items as $image ): ?>
						<div class="item">
							<figure class="overlay"><a href="<?php echo $image['url']; ?>" class="lgitem"><span
										class="over"></span>
									<img src="<?php echo $image['sizes']['tn250x250']; ?>"></a>
							</figure>
						</div>
					<?php endforeach; ?>
				</div>


			<?php endif; ?>
		<?php endif; ?>

		<?php
	endwhile;

	wp_reset_query();

	?>
	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

add_shortcode( 'gallery-view', 'gallery_view_shortcode' );

function gallery_view_vc() {
	vc_map( array(
		"name"     => "Gallery View",
		"base"     => "gallery-view",
		"class"    => "",
		"category" => "Content",
		"params"   => array(
			array(
				'param_name'  => 'gallery',
				'heading'     => "Select Gallery",
				'type'        => 'dropdown',
				"value"       => array_flip( get_galleries_list() ),
				'save_always' => true
			),
			array(
				'param_name'  => 'gallery_type',
				'heading'     => "Gallery View Type",
				'type'        => 'dropdown',
				"value"       => array(
					'Grid'     => 'grid',
					'Flow'     => 'flow',
					'Fotorama' => 'fotorama',
					'Carousel' => 'carousel',
				),
				'std'         => 'fotorama',
				'save_always' => true
			),
			array(
				'param_name'  => 'list_orderby',
				'heading'     => 'List Order By',
				'type'        => 'dropdown',
				"value"       => array(
					'Date'       => 'date',
					'Order'      => 'order',
					'Author'     => 'author',
					'Title'      => 'title',
					'Modified'   => 'modified',
					'ID'         => 'ID',
					'Randomized' => 'rand',
				),
				'std'         => 'order',
				'save_always' => true
			),
			array(
				'param_name'  => 'list_order',
				'heading'     => 'List Order',
				'type'        => 'dropdown',
				"value"       => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC',
				),
				'save_always' => true
			),
			array(
				'param_name'  => 'category_filter',
				'heading'     => "Use Category Filter",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => 1,
				"std"         => 1,
				'save_always' => true
			),
			array(
				'param_name'  => 'lightbox',
				'heading'     => "Use Lightbox",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => 1,
				"std"         => 1,
				'save_always' => true
			),
			array(
				'param_name'  => 'id',
				'heading'     => 'ID',
				'description' => 'Unique ID',
				'type'        => 'textfield',
				'value'       => ''
			),
			array(
				"type"        => "textfield",
				"holder"      => "div",
				"class"       => "",
				"heading"     => "Class",
				"param_name"  => "class",
				"value"       => "",
				"description" => "Class Name."
			),
		),
	) );
}

add_action( 'vc_before_init', 'gallery_view_vc' );



if( function_exists('acf_add_local_field_group') ):

	acf_add_local_field_group(array (
		'key' => 'group_5687c4eee2e59',
		'title' => 'Gallery',
		'fields' => array (
			array (
				'key' => 'field_5687c5f44cca8',
				'label' => 'Title',
				'name' => 'title',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_5687c4f44cca5',
				'label' => 'Gallery Items',
				'name' => 'gallery_items',
				'type' => 'gallery',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'min' => '',
				'max' => '',
				'preview_size' => 'thumbnail',
				'library' => 'all',
				'min_width' => '',
				'min_height' => '',
				'min_size' => '',
				'max_width' => '',
				'max_height' => '',
				'max_size' => '',
				'mime_types' => '',
			),
			array (
				'key' => 'field_56f81528c36e91',
				'label' => 'Gallery View Type',
				'name' => 'gallery_view_type',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'fotorama' => 'Fotorama',
					'flow' => 'Flow (Revolution Slider)',
					'grid' => 'Grid (Isotope)',
					'carousel' => 'Carousel (Owl Carousel)',
				),
				'default_value' => array (
				),
				'allow_null' => 0,
				'multiple' => 0,
				'ui' => 0,
				'ajax' => 0,
				'placeholder' => '',
				'disabled' => 0,
				'readonly' => 0,
			),
			array (
				'key' => 'field_56f81674c36ea1',
				'label' => 'Gallery Data-Attributes',
				'name' => 'gallery-data-attributes',
				'type' => 'textarea',
				'instructions' => 'Add data-attribute per line',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'new_lines' => 'wpautop',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_5687c53e4cca7',
				'label' => 'Description',
				'name' => 'description',
				'type' => 'textarea',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'new_lines' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_5687c51f4cca6',
				'label' => 'Date',
				'name' => 'date',
				'type' => 'date_picker',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'display_format' => 'd/m/Y',
				'return_format' => 'd/m/Y',
				'first_day' => 1,
			),
			array (
				'key' => 'field_5687e83e6163a',
				'label' => 'Gallery Order',
				'name' => 'gallery_order',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'gallery',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'seamless',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen' => array (
			0 => 'tags',
		),
		'active' => 1,
		'description' => '',
	));

endif;


add_action('init','smt_gallery_fn');

function smt_gallery_fn(){
	add_image_size( 'tn70x70', 70, 70, true );
	add_image_size( 'tn90x90', 90, 90, true );
	add_image_size( 'tn270x9999', 270, 9999, true );
	add_image_size( 'tn270x150', 270, 150, true );
	add_image_size( 'tn250x250', 250, 250, true );
	add_image_size( 'tn400x400', 400, 400, true );
	add_image_size( 'tn440x300', 440, 300, true );
	add_image_size( 'tn440x440', 440, 440, true );
	add_image_size( 'tn790x9999', 790, 9999, false );
	add_image_size( 'tn790x400', 790, 400, true );
	add_image_size( 'tn730x4002', 730, 400, false );
	add_image_size( 'tn9999x400', 9999, 400, false );
	add_image_size( 'tn9999x440', 9999, 440, true );
	add_image_size( 'tn9999x110', 9999, 110, array( 'top', 'center' ) );
	add_image_size( 'tn9999x300', 9999, 300, array( 'top', 'center' ) );
}
