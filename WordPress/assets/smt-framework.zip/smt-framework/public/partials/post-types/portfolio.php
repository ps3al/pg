<?php
/**
 * Created by PhpStorm.
 * User: MacBook
 * Date: 27.02.16
 * Time: 00:57
 */


// Register Custom Post Type
function portfolio_post_type() {

	$labels = array(
		'name'                  => _x( 'Portfolios', 'Post Type General Name', 'sipsak' ),
		'singular_name'         => _x( 'Portfolio', 'Post Type Singular Name', 'sipsak' ),
		'menu_name'             => __( 'Portfolios', 'sipsak' ),
		'name_admin_bar'        => __( 'Portfolio', 'sipsak' ),
		'archives'              => __( 'Portfolio Archives', 'sipsak' ),
		'parent_item_colon'     => __( 'Parent Item:', 'sipsak' ),
		'all_items'             => __( 'All Portfolios', 'sipsak' ),
		'add_new_item'          => __( 'Add New Portfolio', 'sipsak' ),
		'add_new'               => __( 'Add New', 'sipsak' ),
		'new_item'              => __( 'New Portfolio', 'sipsak' ),
		'edit_item'             => __( 'Edit Portfolio', 'sipsak' ),
		'update_item'           => __( 'Update Portfolio', 'sipsak' ),
		'view_item'             => __( 'View Portfolio', 'sipsak' ),
		'search_items'          => __( 'Search Portfolio', 'sipsak' ),
		'not_found'             => __( 'Not found', 'sipsak' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'sipsak' ),
		'featured_image'        => __( 'Featured Image', 'sipsak' ),
		'set_featured_image'    => __( 'Set featured image', 'sipsak' ),
		'remove_featured_image' => __( 'Remove featured image', 'sipsak' ),
		'use_featured_image'    => __( 'Use as featured image', 'sipsak' ),
		'insert_into_item'      => __( 'Insert into portfolio', 'sipsak' ),
		'uploaded_to_this_item' => __( 'Uploaded to this portfolio', 'sipsak' ),
		'items_list'            => __( 'Portfolios list', 'sipsak' ),
		'items_list_navigation' => __( 'Portfolios list navigation', 'sipsak' ),
		'filter_items_list'     => __( 'Filter portfolios list', 'sipsak' ),
	);
	$args   = array(
		'label'               => __( 'Portfolio', 'sipsak' ),
		'description'         => __( 'Portfolio Post Type', 'sipsak' ),
		'labels'              => $labels,
		'supports'            => array( 'title','editor', 'thumbnail' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-portfolio',
		'show_in_admin_bar'   => true,
		'show_in_nav_menus'   => true,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'portfolio', $args );
}

add_action( 'init', 'portfolio_post_type', 0 );

function portfolio_taxonomy_category() {

	$labels = array(
		'name'                       => _x( 'Categories', 'Taxonomy General Name', 'sipsak' ),
		'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'sipsak' ),
		'menu_name'                  => __( 'Categories', 'sipsak' ),
		'all_items'                  => __( 'All Categories', 'sipsak' ),
		'parent_item'                => __( 'Parent Category', 'sipsak' ),
		'parent_item_colon'          => __( 'Parent Category:', 'sipsak' ),
		'new_item_name'              => __( 'New Category Name', 'sipsak' ),
		'add_new_item'               => __( 'Add New Category', 'sipsak' ),
		'edit_item'                  => __( 'Edit Category', 'sipsak' ),
		'update_item'                => __( 'Update Category', 'sipsak' ),
		'view_item'                  => __( 'View Category', 'sipsak' ),
		'separate_items_with_commas' => __( 'Separate categories with commas', 'sipsak' ),
		'add_or_remove_items'        => __( 'Add or remove categories', 'sipsak' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'sipsak' ),
		'popular_items'              => __( 'Popular Categories', 'sipsak' ),
		'search_items'               => __( 'Search Categories', 'sipsak' ),
		'not_found'                  => __( 'Not Found', 'sipsak' ),
		'no_terms'                   => __( 'No Categories', 'sipsak' ),
		'items_list'                 => __( 'Categories list', 'sipsak' ),
		'items_list_navigation'      => __( 'Categories list navigation', 'sipsak' ),
	);
	$args   = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => false,
		'show_in_nav_menus' => false,
		'show_tagcloud'     => true,
	);
	register_taxonomy( 'portfolio_category', array( 'portfolio' ), $args );

}

add_action( 'init', 'portfolio_taxonomy_category', 0 );

function portfolio_taxonomy_tag() {

	$labels = array(
		'name'                       => _x( 'Tags', 'Taxonomy General Name', 'sipsak' ),
		'singular_name'              => _x( 'Tag', 'Taxonomy Singular Name', 'sipsak' ),
		'menu_name'                  => __( 'Tags', 'sipsak' ),
		'all_items'                  => __( 'All Tags', 'sipsak' ),
		'new_item_name'              => __( 'New Tag Name', 'sipsak' ),
		'add_new_item'               => __( 'Add New Tag', 'sipsak' ),
		'edit_item'                  => __( 'Edit Tag', 'sipsak' ),
		'update_item'                => __( 'Update Tag', 'sipsak' ),
		'view_item'                  => __( 'View Tag', 'sipsak' ),
		'separate_items_with_commas' => __( 'Separate tags with commas', 'sipsak' ),
		'add_or_remove_items'        => __( 'Add or remove tags', 'sipsak' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'sipsak' ),
		'popular_items'              => __( 'Popular Tags', 'sipsak' ),
		'search_items'               => __( 'Search Tags', 'sipsak' ),
		'not_found'                  => __( 'Not Found', 'sipsak' ),
		'no_terms'                   => __( 'No Tags', 'sipsak' ),
		'items_list'                 => __( 'Tags list', 'sipsak' ),
		'items_list_navigation'      => __( 'Tags list navigation', 'sipsak' ),
	);
	$args   = array(
		'labels'            => $labels,
		'hierarchical'      => false,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => false,
		'show_in_nav_menus' => false,
		'show_tagcloud'     => true,
	);
	register_taxonomy( 'portfolio_tag', array( 'portfolio' ), $args );

}

add_action( 'init', 'portfolio_taxonomy_tag', 0 );



function wpb_change_portfolio_title_text( $title ){
	$screen = get_current_screen();

	if  ( 'portfolio' == $screen->post_type ) {
		$title = 'Enter portfolio name';
	}

	return $title;
}

add_filter( 'enter_title_here', 'wpb_change_portfolio_title_text' );


function acf_load_select_gallery_choices( $field ) {

	// reset choices
	$field['choices'] = array();


	// get the textarea value from options page without any formatting
	$choices = get_galleries_list();


	// explode the value so that each line is a new array piece
	//$choices = explode(",", $choices);


	// remove any unwanted white space
	//$choices = array_map('trim', $choices);


	// loop through array and add to field 'choices'
	if( is_array($choices) ) {

		foreach( $choices as $choice ) {

			$field['choices'][ $choice ] = $choice;

		}

	}


	// return the field
	return $field;

}

add_filter('acf/load_field/name=select_gallery', 'acf_load_select_gallery_choices');



add_action('acf/input/admin_head', 'portfolio_acf_admin_head');

function portfolio_acf_admin_head() {

	?>
	<script type="text/javascript">
		(function ($) {

			$(document).ready(function() {

				$('.acf-field-56f73023bde6c .acf-input').append($('#postdivrich'));

			});

		})(jQuery);
	</script>
	<style type="text/css">
		.acf-field #wp-content-editor-tools {
			background: transparent;
			padding-top: 0;
		}
	</style>

	<?php
}



function get_portfolios_list() {

	$portfolios_query = query_posts( 'posts_per_page=-1&post_type=portfolio&orderby=title&order=ASC' );
	$portfolios_array = array();
	if ( is_array( $portfolios_array ) ) {
		foreach ( $portfolios_query as $portfolio ) {
			$portfolios_array[ $portfolio->ID ] = $portfolio->post_title;
		}
	}
	wp_reset_query();

//	var_dump($portfolios_array);
//	die;

	return $portfolios_array;

}



if( function_exists('acf_add_local_field_group') ):

	acf_add_local_field_group(array (
		'key' => 'group_56f72e4c8a1b1',
		'title' => 'Portfolio',
		'fields' => array (
			array (
				'key' => 'field_56f72e60bde67',
				'label' => 'Title',
				'name' => 'title',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_56f7300bbde6b',
				'label' => 'Description',
				'name' => 'description',
				'type' => 'textarea',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'new_lines' => 'wpautop',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_56f73023bde6c',
				'label' => 'Content',
				'name' => '',
				'type' => 'message',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'message' => '',
				'new_lines' => 'wpautop',
				'esc_html' => 0,
			),
			array (
				'key' => 'field_56f72e99bde68',
				'label' => 'Gallery',
				'name' => 'gallery_type',
				'type' => 'radio',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'select' => 'Select from Galleries',
					'create' => 'Create own Gallery',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'select',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_56f72f90bde69',
				'label' => 'Select Gallery',
				'name' => 'select_gallery',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array (
					array (
						array (
							'field' => 'field_56f72e99bde68',
							'operator' => '==',
							'value' => 'select',
						),
					),
				),
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'' => '',
					'Deneme Gallery' => 'Deneme Gallery',
				),
				'default_value' => array (
				),
				'allow_null' => 0,
				'multiple' => 0,
				'ui' => 0,
				'ajax' => 0,
				'placeholder' => '',
				'disabled' => 0,
				'readonly' => 0,
			),
			array (
				'key' => 'field_56f72fbfbde6a',
				'label' => 'Create Own Gallery',
				'name' => 'create_gallery',
				'type' => 'gallery',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array (
					array (
						array (
							'field' => 'field_56f72e99bde68',
							'operator' => '==',
							'value' => 'create',
						),
					),
				),
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'min' => '',
				'max' => '',
				'preview_size' => 'thumbnail',
				'library' => 'all',
				'min_width' => '',
				'min_height' => '',
				'min_size' => '',
				'max_width' => '',
				'max_height' => '',
				'max_size' => '',
				'mime_types' => '',
			),
			array (
				'key' => 'field_56f81528c36e9',
				'label' => 'Gallery View Type',
				'name' => 'create_gallery_view_type',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array (
					array (
						array (
							'field' => 'field_56f72e99bde68',
							'operator' => '==',
							'value' => 'create',
						),
					),
				),
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'fotorama' => 'Fotorama',
					'flow' => 'Flow (Revolution Slider)',
					'grid' => 'Grid (Isotope)',
					'carousel' => 'Carousel (Owl Carousel)',
				),
				'default_value' => array (
				),
				'allow_null' => 0,
				'multiple' => 0,
				'ui' => 0,
				'ajax' => 0,
				'placeholder' => '',
				'disabled' => 0,
				'readonly' => 0,
			),
			array (
				'key' => 'field_56f8211ed4808',
				'label' => 'Gallery View Type',
				'name' => 'select_gallery_view_type',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array (
					array (
						array (
							'field' => 'field_56f72e99bde68',
							'operator' => '==',
							'value' => 'select',
						),
					),
				),
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					0 => 'Gallery Default',
					'fotorama' => 'Fotorama',
					'flow' => 'Flow (Revolution Slider)',
					'grid' => 'Grid (Isotope)',
					'carousel' => 'Carousel (Owl Carousel)',
				),
				'default_value' => array (
				),
				'allow_null' => 0,
				'multiple' => 0,
				'ui' => 0,
				'ajax' => 0,
				'placeholder' => '',
				'disabled' => 0,
				'readonly' => 0,
			),
			array (
				'key' => 'field_56f81674c36ea',
				'label' => 'Gallery Data-Attributes',
				'name' => 'gallery-data-attributes',
				'type' => 'textarea',
				'instructions' => 'Add data-attribute per line',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'new_lines' => 'wpautop',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_56f73054bde6d',
				'label' => 'Order',
				'name' => 'order',
				'type' => 'number',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'min' => '',
				'max' => '',
				'step' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'portfolio',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'seamless',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen' => '',
		'active' => 1,
		'description' => '',
	));

endif;


if( function_exists('acf_add_local_field_group') ):
/*
	acf_add_local_field_group(array (
		'key' => 'group_56f72e4c8a1b1',
		'title' => 'Portfolio2',
		'fields' => array (
			array (
				'key' => 'field_56f72e60bde67',
				'label' => 'Title',
				'name' => 'title',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_56f7300bbde6b',
				'label' => 'Description',
				'name' => 'description',
				'type' => 'textarea',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'new_lines' => 'wpautop',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_56f73023bde6c',
				'label' => 'Content',
				'name' => '',
				'type' => 'message',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'message' => '',
				'new_lines' => 'wpautop',
				'esc_html' => 0,
			),
			array (
				'key' => 'field_56f72e99bde68',
				'label' => 'Gallery',
				'name' => 'gallery_type',
				'type' => 'radio',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'select' => 'Select from Galleries',
					'create' => 'Create own Gallery',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'select',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_56f72f90bde69',
				'label' => 'Select Gallery',
				'name' => 'select_gallery',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array (
					array (
						array (
							'field' => 'field_56f72e99bde68',
							'operator' => '==',
							'value' => 'select',
						),
					),
				),
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'' => '',
				),
				'default_value' => array (
				),
				'allow_null' => 0,
				'multiple' => 0,
				'ui' => 0,
				'ajax' => 0,
				'placeholder' => '',
				'disabled' => 0,
				'readonly' => 0,
			),
			array (
				'key' => 'field_56f72fbfbde6a',
				'label' => 'Create Own Gallery',
				'name' => 'create_gallery',
				'type' => 'gallery',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array (
					array (
						array (
							'field' => 'field_56f72e99bde68',
							'operator' => '==',
							'value' => 'create',
						),
					),
				),
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'min' => '',
				'max' => '',
				'preview_size' => 'thumbnail',
				'library' => 'all',
				'min_width' => '',
				'min_height' => '',
				'min_size' => '',
				'max_width' => '',
				'max_height' => '',
				'max_size' => '',
				'mime_types' => '',
			),
			array (
				'key' => 'field_56f81528c36e9',
				'label' => 'Gallery View Type',
				'name' => 'gallery_view_type',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array (
					'fotorama' => 'Fotorama',
					'flow' => 'Flow (Revolution Slider)',
					'grid' => 'Grid (Isotope)',
					'carousel' => 'Carousel (Owl Carousel)',
				),
				'default_value' => array (
				),
				'allow_null' => 0,
				'multiple' => 0,
				'ui' => 0,
				'ajax' => 0,
				'placeholder' => '',
				'disabled' => 0,
				'readonly' => 0,
			),
			array (
				'key' => 'field_56f81674c36ea',
				'label' => 'Gallery Data-Attributes',
				'name' => 'gallery-data-attributes',
				'type' => 'textarea',
				'instructions' => 'Add data-attribute per line',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'new_lines' => 'wpautop',
				'readonly' => 0,
				'disabled' => 0,
			),
			array (
				'key' => 'field_56f73054bde6d',
				'label' => 'Portfolio Order',
				'name' => 'order',
				'type' => 'number',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'min' => '',
				'max' => '',
				'step' => '',
				'readonly' => 0,
				'disabled' => 0,
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'portfolio',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'seamless',
		'label_placement' => 'left',
		'instruction_placement' => 'label',
		'hide_on_screen' => '',
		'active' => 1,
		'description' => '',
	));
*/
endif;


