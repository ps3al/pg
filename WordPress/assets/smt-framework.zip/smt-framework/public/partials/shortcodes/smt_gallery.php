<?php
/**
 * Created by PhpStorm.
 * User: MacBook
 * Date: 26.02.16
 * Time: 18:19
 */

// Portfolio View Shortcode
function smt_gallery( $atts ) {
	ob_start();
	// Attributes
	extract( shortcode_atts(
			array(
				'gallery'         => '',
				'gallery_type'    => 'fotorama',
				'category_filter' => true,
				'lightbox'        => true,
				'list_orderby'    => 'order',
				'list_order'      => 'ASC'
			), $atts )
	);
	?>
	<?php

	//general query
	$args = array(
		'post_status' => 'publish',
		'post_type'   => 'gallery',
		'post__in'    => array( $gallery ),
		'orderby'     => $list_orderby,
		'order'       => $list_order,
		'showposts'   => 1000
	);


	$theQuery = query_posts( $args );

	while ( have_posts() ) : the_post();

		$title       = get_field( 'title' );
		$description = get_field( 'description' );
		$items       = get_field( 'gallery_items' );

		if ( $items ): ?>
			<?php if ( 'fotorama' == $gallery_type ): ?>
				<div class="fotorama-wrapper">
					<div class="fotorama"
					     data-width="100%"
					     data-height="100%"
					     data-autoplay="8000"
					     data-keyboard="true"
					     data-arrows="true"
					     data-click="false"
					     data-fit="cover"
					     data-swipe="true"
					     data-nav="thumbs"
					     data-transition="slide"
					     data-clicktransition="crossfade"
					     data-thumbwidth="90"
					     data-thumbheight="50">

						<?php foreach ( $items as $image ): ?>
							<img src="<?php echo $image['url']; ?>" data-caption="<?php echo $image['caption']; ?>"
							     data-fit="content"
							     alt=""/>
						<?php endforeach; ?>

					</div>
					<!-- /.fotorama -->
				</div>
			<?php elseif ( 'flow' == $gallery_type ): ?>

				<div class="rev_slider_wrapper" style="background-color:#171717; padding:0px;">
					<div id="flow" class="rev_slider fullscreenbanner" data-version="5.0">
						<ul>
							<?php foreach ( $items as $image ): ?>
								<li data-transition="fade"><img src="<?php echo $image['url']; ?>" alt=""
								                                data-bgposition="center center">
									<?php if ( '' != $image['caption'] ): ?>
										<div class="tp-caption display dark-layer"
										     data-x="40"
										     data-y="bottom"
										     data-voffset="40"
										     data-fontsize="['26','26','26','26']"
										     data-lineheight="['32','32','32','30']"
										     data-transform_idle="o:1;"
										     data-transform_in="y:50px;opacity:0;s:1500;e:Power3.easeOut;"
										     data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
										     data-start="50"
										     data-splitin="none"
										     data-splitout="none"
										     data-responsive_offset="on"
										     style="z-index: 5;"><?php echo $image['caption']; ?></div>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					<!-- /.rev_slider -->
				</div>
				<!-- /.rev_slider_wrapper -->


			<?php elseif ( 'grid' == $gallery_type ):
				?>


				<div class="gallery-grid">

					<?php if ( $category_filter ): ?>
						<div class="isotope-filter button-group">
							<ul>
								<li><a class="button is-checked" data-filter="*">All</a></li>
								<?php

								$categories = array();
								foreach ( $items as $image ) {
									$xcategories = get_field( 'category', $image['ID'] );
									if ( $xcategories ) {
										foreach ( $xcategories as $category ) {
//							echo ',' . $category->ID;
											$categories[] = $category->name;
										}
									}
								}
								$categories = array_unique( $categories );
								sort( $categories, SORT_LOCALE_STRING );

								foreach ( $categories as $category ):?>
									<li><a class="button"
									       data-filter=".cat-<?php echo $category ?>"><?php echo $category ?></a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
					<ul class="isotope items<?php echo $lightbox ? ' light-gallery' : ''; ?>">
						<?php foreach ( $items as $image ):
							$categories  = '';
							$xcategories = get_field( 'category', $image['ID'] );
							if ( $xcategories ) {
								foreach ( $xcategories as $category ) {
									$categories .= ' cat-' . $category->name;
								}
							}

							?>
							<li class="item<?php echo $categories; ?>">
								<figure class="overlay inverse"><a href="<?php echo $image['url']; ?>" class="lgitem"
								                                   data-sub-html="#caption1">
										<div class="text-overlay caption" id="caption1">
											<div class="info">
												<h2 class="post-title"><?php echo $image['title']; ?></h2>

												<p><?php echo $image['caption']; ?></p>
											</div>
										</div>
										<img src="<?php echo $image['sizes']['tn440x300']; ?>" alt=""/> </a></figure>
							</li>
						<?php endforeach; ?>
					</ul>
					<!-- /.isotope -->
				</div>
				<!-- /.gallery-grid -->


			<?php elseif ( 'carousel' == $gallery_type ): ?>

				<div class="owl-carousel<?php echo $lightbox ? ' light-gallery' : ''; ?>">
					<?php foreach ( $items as $image ): ?>
						<div class="item">
							<figure class="overlay"><a href="<?php echo $image['url']; ?>" class="lgitem"><span
										class="over"></span>
									<img src="<?php echo $image['sizes']['tn250x250']; ?>"></a>
							</figure>
						</div>
					<?php endforeach; ?>
				</div>


			<?php endif; ?>
		<?php endif; ?>

		<?php
	endwhile;

	wp_reset_query();

	?>
	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

function smt_gallery_vc() {
	vc_map( array(
		"name"     => "Portfolio",
		"base"     => "smt_gallery",
		"class"    => "",
		"category" => "Content",
		"params"   => array(
			array(
				'param_name'  => 'gallery',
				'heading'     => "Select Portfolio",
				'type'        => 'dropdown',
				"value"       => array_flip( get_galleries_list() ),
				'save_always' => true
			),
			array(
				'param_name'  => 'gallery_type',
				'heading'     => "Portfolio View Type",
				'type'        => 'dropdown',
				"value"       => array(
					'Grid'     => 'grid',
					'Flow'     => 'flow',
					'Fotorama' => 'fotorama',
					'Carousel' => 'carousel',
				),
				'std'         => 'fotorama',
				'save_always' => true
			),
			array(
				'param_name'  => 'list_orderby',
				'heading'     => 'List Order By',
				'type'        => 'dropdown',
				"value"       => array(
					'Date'       => 'date',
					'Order'      => 'order',
					'Author'     => 'author',
					'Title'      => 'title',
					'Modified'   => 'modified',
					'ID'         => 'ID',
					'Randomized' => 'rand',
				),
				'std'         => 'order',
				'save_always' => true
			),
			array(
				'param_name'  => 'list_order',
				'heading'     => 'List Order',
				'type'        => 'dropdown',
				"value"       => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC',
				),
				'save_always' => true
			),
			array(
				'param_name'  => 'category_filter',
				'heading'     => "Use Category Filter",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => 1,
				"std"         => 1,
				'save_always' => true
			),
			array(
				'param_name'  => 'lightbox',
				'heading'     => "Use Lightbox",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => 1,
				"std"         => 1,
				'save_always' => true
			),
			array(
				'param_name'  => 'id',
				'heading'     => 'ID',
				'description' => 'Unique ID',
				'type'        => 'textfield',
				'value'       => ''
			),
			array(
				"type"        => "textfield",
				"holder"      => "div",
				"class"       => "",
				"heading"     => "Class",
				"param_name"  => "class",
				"value"       => "",
				"description" => "Class Name."
			),
		),
	) );
}

