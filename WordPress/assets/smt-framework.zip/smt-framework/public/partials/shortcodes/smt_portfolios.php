<?php
/**
 * Created by PhpStorm.
 * User: MacBook
 * Date: 26.02.16
 * Time: 18:19
 */

//WP Portfolios Grid Shortcode
function smt_portfolios( $atts ) {
	ob_start();
	// Attributes
	extract( shortcode_atts(
			array(
				'portfolios'    => 'all',
				'show_title'   => true,
				'show_desc'    => true,
				'show_meta'    => true,
				'list_orderby' => 'order',
				'list_order'   => 'ASC'
			), $atts )
	);
	?>
	<div class="portfolios-grid">
		<ul class="isotope items">
			<?php

			$args = array(
				'post_status' => 'publish',
				'post_type'   => 'portfolio',
				'orderby'     => $list_orderby,
				'order'       => $list_order,
				'showposts'   => 1000
			);

			if ( 'all' != $portfolios ) {
				//portfolio id numbers
				$ids = ! empty( $portfolios ) ? explode( ",", trim( $portfolios ) ) : array();

				if ( ! empty ( $ids ) ) {
					$args = array_merge( $args, array( 'post__in' => $ids ) );
				}
			}

			$theQuery = query_posts( $args );

			while ( have_posts() ) : the_post();

				$title       = get_field( 'title' );
				$description = get_field( 'description' );
				$items       = get_field( 'portfolio_items' );

				$date = get_field( 'date' );

				?>
				<li class="item">
					<figure class="overlay"><a href="<?php echo get_permalink(); ?>">
							<div class="text-overlay caption">
								<?php if ( $show_title || $show_desc || $show_meta ): ?>
									<div class="info">
										<?php if ( $show_title ): ?>
											<h2 class="post-title"><?php echo $title; ?></h2>
										<?php endif; ?>
										<?php if ( $show_desc ): ?>
											<h6 class="post-title"><?php echo $description; ?></h6>
										<?php endif; ?>
										<?php if ( $show_meta ): ?>
											<div class="meta">
												<span
													class="count"><?php echo $items == false ? '0' : count( $items ); ?>
													Photos</span>
												<span class="date"><?php echo $date; ?></span>
											</div>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							</div>
							<img src="<?php echo get_featured_image_url( $post->ID, 'tn440x300' ); ?>"
							     alt=""/> </a>
					</figure>
				</li>
				<?php
			endwhile;

			wp_reset_query();

			?>
		</ul>
		<!-- /.isotope -->
	</div>
	<!-- /.portfolios-grid -->
	<?php
	$output_string = ob_get_contents();
	ob_end_clean();

	return $output_string;
}

//VC
function smt_portfolios_vc() {
	vc_map( array(
		"name"     => "SMT Portfolios VC",
		"base"     => "smt_portfolios",
		"class"    => "",
		"category" => "Content",
		"params"   => array(
			array(
				'param_name' => 'portfolios',
				'heading'    => "Select Portfolios",
				'type'       => 'dropdown_multi',
				"value"      => array_merge( array( "All Portfolios" => "" ), array_flip( get_portfolios_list() ) )
			),
			array(
				'param_name'  => 'list_orderby',
				'heading'     => 'List Order By',
				'type'        => 'dropdown',
				"value"       => array(
					'Date'       => 'date',
					'Order'      => 'order',
					'Author'     => 'author',
					'Title'      => 'title',
					'Modified'   => 'modified',
					'ID'         => 'ID',
					'Randomized' => 'rand',
				),
				'std'         => 'order',
				'save_always' => true
			),
			array(
				'param_name'  => 'list_order',
				'heading'     => 'List Order',
				'type'        => 'dropdown',
				"value"       => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC',
				),
				'save_always' => true
			),
			array(
				'param_name'  => 'show_title',
				'heading'     => "Show Title",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => true,
				"std"         => true
			),
			array(
				'param_name'  => 'show_desc',
				'heading'     => "Show Description",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => true,
				"std"         => true
			),
			array(
				'param_name'  => 'show_meta',
				'heading'     => "Show Meta",
				"description" => "",
				'type'        => 'checkbox',
				"value"       => true,
				"std"         => true
			),
			array(
				'param_name'  => 'id',
				'heading'     => 'ID',
				'description' => 'Unique ID',
				'type'        => 'textfield',
				'value'       => ''
			),
			array(
				"type"        => "textfield",
				"holder"      => "div",
				"class"       => "",
				"heading"     => "Class",
				"param_name"  => "class",
				"value"       => "",
				"description" => "Class Name."
			),
		),
	) );
}

//SU
function register_smt_portfolios_shortcode( $shortcodes ) {


	// Add new shortcode
	$shortcodes['smt_portfolios'] = array(
		// Shortcode name
		'name'     => __( 'SMT Portfolios', 'textdomain' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'wrap',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'content',
		// List of shortcode params (attributes)
		'atts'     => array(
			// Style attribute
			'id'    => array(
				// Attribute type.
				// Can be 'select', 'color', 'bool' or 'text'
				'type' => 'text',
				// Available values
				// Default value
				// Attribute name
				'name' => __( 'ID', 'textdomain' ),
				// Attribute description
				'desc' => __( 'Bartag ID', 'textdomain' )
			),
			'class' => array(
				// Attribute type.
				// Can be 'select', 'color', 'bool' or 'text'
				'type' => 'text',
				// Available values
				// Default value
				// Attribute name
				'name' => __( 'Class', 'textdomain' ),
				// Attribute description
				'desc' => __( 'Bartag Class', 'textdomain' )
			)
		),
		// Default content for generator (for wrap-type shortcodes)
		'content'  => __( 'Bartag text', 'textdomain' ),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Styled heading 2', 'textdomain' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'sm_bartag'
	);
//	echo 'sdasdasdasdasdasdasdasdasdasdasdasdasdasdasd';
//	die;

//	var_dump($shortcodes);
//	die;

	// Return modified data
	return $shortcodes;
}







