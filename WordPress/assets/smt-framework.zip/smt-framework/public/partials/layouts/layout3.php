<?php
/**
 * SM-Theme Layout 1
 *
 * @author 		SM-Themes
 */
$data                 = array();
$data['weight']       = 0;
$data['name']         = esc_html__( '3. Layout 3', 'healthflex' );
$data['description']         = 'Test Layout 3';
//$data['image_path']   = preg_replace( '/\s/', '%20', get_template_directory_uri() . '/assets/images/visualcomposer/home.jpg' );
$data['custom_class'] = 'custom_template_for_vc_custom_template';
$data['content']      = '[vc_row][vc_column][vc_column_text]Test 1[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="1/2"][vc_icon icon_fontawesome="fa fa-anchor" background_style="rounded-less" size="lg"][/vc_column][vc_column width="1/2"][vc_icon icon_fontawesome="fa fa-birthday-cake" background_style="rounded-less" size="lg"][/vc_column][/vc_row]';
$data['value'] = 'a:3:{s:7:"widgets";a:2:{i:0;a:4:{s:5:"title";s:6:"Text 1";s:4:"text";s:9:"Content 1";s:6:"filter";b:0;s:11:"panels_info";a:6:{s:5:"class";s:14:"WP_Widget_Text";s:3:"raw";b:0;s:4:"grid";i:0;s:4:"cell";i:0;s:2:"id";i:0;s:5:"style";a:2:{s:27:"background_image_attachment";b:0;s:18:"background_display";s:4:"tile";}}}i:1;a:4:{s:5:"title";s:6:"Text 2";s:4:"text";s:9:"Content 2";s:6:"filter";b:0;s:11:"panels_info";a:6:{s:5:"class";s:14:"WP_Widget_Text";s:3:"raw";b:0;s:4:"grid";i:0;s:4:"cell";i:1;s:2:"id";i:1;s:5:"style";a:2:{s:27:"background_image_attachment";b:0;s:18:"background_display";s:4:"tile";}}}}s:5:"grids";a:1:{i:0;a:2:{s:5:"cells";i:2;s:5:"style";a:0:{}}}s:10:"grid_cells";a:2:{i:0;a:2:{s:4:"grid";i:0;s:6:"weight";d:0.5;}i:1;a:2:{s:4:"grid";i:0;s:6:"weight";d:0.5;}}}';


?>