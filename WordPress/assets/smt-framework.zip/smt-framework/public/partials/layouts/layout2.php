<?php
/**
 * SM-Theme Layout 1
 *
 * @author 		SM-Themes
 */
$data                 = array();
$data['weight']       = 0;
$data['name']         = esc_html__( '2. Layout 2222', 'healthflex' );
$data['description']         = 'Video Background';
//$data['image_path']   = preg_replace( '/\s/', '%20', get_template_directory_uri() . '/assets/images/visualcomposer/home.jpg' );
$data['custom_class'] = 'custom_template_for_vc_custom_template';
$data['content']      = '[vc_row][vc_column][vc_column_text]Test 1[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="1/2"][vc_icon icon_fontawesome="fa fa-anchor" background_style="rounded-less" size="lg"][/vc_column][vc_column width="1/2"][vc_icon icon_fontawesome="fa fa-birthday-cake" background_style="rounded-less" size="lg"][/vc_column][/vc_row]';
$data['value'] = 'a:3:{s:7:"widgets";a:3:{i:0;a:4:{s:5:"title";s:0:"";s:4:"text";s:0:"";s:11:"panels_info";a:4:{s:5:"class";s:14:"WP_Widget_Text";s:4:"grid";i:0;s:4:"cell";i:0;s:2:"id";i:0;}s:6:"filter";b:0;}i:1;a:4:{s:5:"title";s:2:"22";s:4:"text";s:3:"222";s:11:"panels_info";a:5:{s:5:"class";s:14:"WP_Widget_Text";s:4:"grid";i:0;s:4:"cell";i:1;s:2:"id";i:1;s:5:"style";a:2:{s:27:"background_image_attachment";b:0;s:18:"background_display";s:4:"tile";}}s:6:"filter";b:0;}i:2;a:4:{s:5:"title";s:0:"";s:4:"text";s:0:"";s:11:"panels_info";a:5:{s:5:"class";s:14:"WP_Widget_Text";s:4:"grid";i:0;s:4:"cell";i:2;s:2:"id";i:2;s:5:"style";a:2:{s:27:"background_image_attachment";b:0;s:18:"background_display";s:4:"tile";}}s:6:"filter";b:0;}}s:5:"grids";a:1:{i:0;a:2:{s:5:"cells";i:3;s:5:"style";a:10:{s:27:"background_image_attachment";b:0;s:18:"background_display";s:4:"tile";s:20:"use_background_video";s:0:"";s:13:"video_overlay";s:4:"none";s:15:"overlay_pattern";s:4:"dots";s:7:"fade_in";b:1;s:11:"pause_after";s:3:"120";s:17:"pause_play_button";b:1;s:14:"pauseplay_xpos";s:5:"right";s:14:"pauseplay_ypos";s:3:"top";}}}s:10:"grid_cells";a:3:{i:0;a:2:{s:4:"grid";i:0;s:6:"weight";d:0.50000000489134;}i:1;a:2:{s:4:"grid";i:0;s:6:"weight";d:0.30901699302301433;}i:2;a:2:{s:4:"grid";i:0;s:6:"weight";d:0.19098300208564575;}}}';

?>
