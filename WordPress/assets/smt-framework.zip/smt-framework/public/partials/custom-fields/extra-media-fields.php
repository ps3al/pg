<?php
/**
 * Created by PhpStorm.
 * User: MacBook
 * Date: 27.02.16
 * Time: 01:36
 */

if( function_exists('acf_add_local_field_group') ):

	acf_add_local_field_group(array (
		'key' => 'group_568831b535709',
		'title' => 'Extra Media Fields',
		'fields' => array (
			array (
				'key' => 'field_5688325b319eb',
				'label' => 'Category',
				'name' => 'category',
				'type' => 'taxonomy',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'taxonomy' => 'gallery_item_category',
				'field_type' => 'checkbox',
				'allow_null' => 0,
				'add_term' => 1,
				'save_terms' => 0,
				'load_terms' => 0,
				'return_format' => 'object',
				'multiple' => 0,
			),
			array (
				'key' => 'field_5688345238d79',
				'label' => 'Tag',
				'name' => 'tag',
				'type' => 'taxonomy',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array (
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'taxonomy' => 'gallery_item_tag',
				'field_type' => 'multi_select',
				'allow_null' => 0,
				'add_term' => 1,
				'save_terms' => 0,
				'load_terms' => 0,
				'return_format' => 'object',
				'multiple' => 0,
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'attachment',
					'operator' => '==',
					'value' => 'all',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'default',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen' => array (
			0 => 'tags',
		),
		'active' => 1,
		'description' => '',
	));

endif;