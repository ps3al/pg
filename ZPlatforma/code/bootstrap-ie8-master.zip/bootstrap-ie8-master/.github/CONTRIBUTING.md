# Contributing

We are happy to accept contributions from the community to improve this project.


## Contributon Guidelines

- Please follow the CSS style format (we'll add a stylelint.rc soon and would recommend using a Stylelint plugin with your code editor to ensure there are no issues)
